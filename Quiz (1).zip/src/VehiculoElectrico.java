
public interface VehiculoElectrico {
    void cargarBateria();
    void mostrarNivelBateria();
}
